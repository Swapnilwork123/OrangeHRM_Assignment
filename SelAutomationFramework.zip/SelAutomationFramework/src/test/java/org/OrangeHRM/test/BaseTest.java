package org.OrangeHRM.test;

import java.util.concurrent.TimeUnit;

import org.ravi.driver.Driver;
import org.ravi.driver.DriverManager;
import org.ravi.reports.GenerateReport;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

public class BaseTest {

	protected BaseTest() {

	}
	

	@BeforeClass
	protected void setUp() throws Exception {
		Driver.initDriver();
		DriverManager.getDriver().manage().window().maximize();
	}
	
	@BeforeMethod
  protected void openUrl() throws Exception {
		Driver.navigateToURL();
		DriverManager.getDriver().manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}

	@AfterClass
	protected void tearDown() {
		Driver.quitDriver();
	}

}
