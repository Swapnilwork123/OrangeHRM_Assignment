package org.OrangeHRM.test;

import org.OrangeHrm.pages.AddEmployeePage;
import org.OrangeHrm.pages.ConfgurationPage;
import org.OrangeHrm.pages.Config_OptionalFieldsPage;
import org.OrangeHrm.pages.Config_personalDetailsPage;
import org.OrangeHrm.pages.EployeeListPage;
import org.OrangeHrm.pages.LoginPage_OrangeHm;
import org.OrangeHrm.pages.TerminationReasonsPage;
import org.assertj.core.api.Assertions;
import org.testng.annotations.Test;

public class OrangeHrm_Test extends BaseTest{
/*
	@Test
	public void verifyLogin() throws InterruptedException {
		String urlAftLogin = new LoginPage_OrangeHm()
				.enterUserName("Admin")
				.enterPassword("admin123")
				.clickOnLoginBtn()
				.getUrl();
		
		Assertions.assertThat("https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewEmployeeList")
		.isEqualTo(urlAftLogin);		
	}
	
	
	@Test(dataProviderClass = org.ravi.dataprovider.DataProviderClass.class, dataProvider = "readFile")
	public void verifyLoginWithMultipeCredentials(String Username, String Password, String Status) throws InterruptedException {
		String urlAfterLogin = new LoginPage_OrangeHm()
				.enterUserName(Username)
				.enterPassword(Password)
				.clickOnLoginBtn()
				.getUrl();
		if(Status.equalsIgnoreCase("Valid")) {
			Assertions.assertThat(urlAfterLogin).
			isEqualTo("https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewEmployeeList");
			
			//new Wishup_LoginPage().logOut();
		}
		else if(Status.equalsIgnoreCase("Invalid")) {
			Assertions.assertThat(urlAfterLogin).
			isNotEqualTo("https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewEmployeeList");
		}
	}
	
	@Test
	public void verifyMethodCreation() throws InterruptedException {
		
		new LoginPage_OrangeHm()
		.enterUserName("Admin")
		.enterPassword("admin123")
		.clickOnLoginBtn();
		
		String str_newMethodName = new ConfgurationPage()
				.clickOnConfiguartion()
				.clikOnReportingMethod()
				.clickOnAddButton()
				.enterNewMethodName()
				.clickOnSaveButton()
				.getMethodName();
		
		Assertions.assertThat(str_newMethodName).isEqualTo("Method_One");
		
		String str_modifiedMethodName = new ConfgurationPage()
	               .clickOnPencilIcon()
	               .modifyMethodName()
	               .clickOnSaveModified()
	               .getModifiedMethodName();
		Assertions.assertThat(str_modifiedMethodName).isEqualTo("Method_Modified");
		
	boolean result = 	new ConfgurationPage()
		.clickOnDeleteButton()
		.clickOnYesDeleteButton()
         .isElementPresent();
	Assertions.assertThat(result).isEqualTo(false);
	
	}
	
	@Test
	public void verifyOptionFields() throws InterruptedException
{
		new LoginPage_OrangeHm()
		.enterUserName("Admin")
		.enterPassword("admin123")
		.clickOnLoginBtn();
		new ConfgurationPage().clickOnConfiguartion();
		new Config_OptionalFieldsPage()
        .clickOnoptionalFieldLink()
        .clickOnSwitchOfShowDepricatedFields()
       .clickOnSSNSwitch()
       .clickOnSINSwitch()
        .clickOnSaveButton();
		
		new EployeeListPage()
		.clickOnemployeeListLink()
		.clickOnEmployeeFromRecord();
		
		boolean nickNameResult = new Config_personalDetailsPage()
        .isNicknameElementPresent();
		Assertions.assertThat(nickNameResult).isEqualTo(false);
		
		boolean SSNNumberResult = new Config_personalDetailsPage()
		      .isSSNnumberElementPresent();
				Assertions.assertThat(SSNNumberResult).isEqualTo(false);
				
		boolean SINNumberResult = new Config_personalDetailsPage()
			 .isSINnumberElementPresent();
			Assertions.assertThat(SINNumberResult).isEqualTo(false);	
	
		boolean milteryServicesResult = new Config_personalDetailsPage()
			 .ismilteryServicesElementPresent();
			Assertions.assertThat(milteryServicesResult).isEqualTo(false);

}
	
	
	@Test
	public void verifyTerminationReason() throws InterruptedException {
		
		new LoginPage_OrangeHm()
		.enterUserName("Admin")
		.enterPassword("admin123")
		.clickOnLoginBtn();
		new ConfgurationPage().clickOnConfiguartion().clickOnTerminationReasonLink();
	String str_newTermiationReason =	new TerminationReasonsPage()
		.clickOnAddButton()
		.enterNewTerminationReason()
		.clickOnSaveButton()
		.getnewMethodName();
	Assertions.assertThat(str_newTermiationReason).isEqualTo("Poor_Work");

	String str_modifiedTermiationReason  =	new TerminationReasonsPage()
	.clickOnPencilIcon()
	.modifyTerminationReason()
	.clickOnSaveButtonAfterModification()
	.getnewMethodNameAfterModification();
	
	Assertions.assertThat(str_modifiedTermiationReason).isEqualTo("non_satisfactory");

	boolean deleteResult = new TerminationReasonsPage()
	 .deleteTermiReason()
	 .yesdeleteTermiReason()
	 .verifyTermiReasonDeleted();
	Assertions.assertThat(deleteResult).isEqualTo(false);
	
	}

	@Test 
	public void verifySearchEmployeeFunctionality() throws InterruptedException {
		
		new LoginPage_OrangeHm()
		.enterUserName("Admin")
		.enterPassword("admin123")
		.clickOnLoginBtn();
		
		String searchResult = new EployeeListPage()
				.enterEmployeeName()
				.enterEmployeeId()
				.clickOnEmployeeStatusDropdown()
				.clickOnSearchButton()
				.verifySearchResult();
		Assertions.assertThat(searchResult).isEqualTo("Jordan");
	
	}
	
	@Test 
	public void verifyEmployeeFunactionalityWithAllInputCriteria() throws InterruptedException {
		
		new LoginPage_OrangeHm()
		.enterUserName("Admin")
		.enterPassword("admin123")
		.clickOnLoginBtn();
		String searchResult=new EployeeListPage()
		.enterEmployeeName()
		.enterEmployeeId()
		.clickOnEmployeeStatusDropdown()
		.enterSupervisorName()
		.selectJobTitle()
		.selectSubUnit()
		.clickOnSearchButton()
		.verifySearchResult();
		Assertions.assertThat(searchResult).isEqualTo("Jordan");	
	}
	*/
	@Test 
	public void verifyAddEmployeeFunctionality() throws InterruptedException {
		
		new LoginPage_OrangeHm()
		.enterUserName("Admin")
		.enterPassword("admin123")
		.clickOnLoginBtn();
		new EployeeListPage().clickOnAddButton();
		new AddEmployeePage()
		.enterFirstName()
		.enterMiddleName()
		.enterLastName()
		.enterEmployeeId()
		.clickOnSaveButton()
		.enterEmployeeNickName()
		.enterDrivingLicenseNum()
		.enterLicenseExpiryDate()
		.enterSSNNum()
		.enterSINNum()
		.selectNationality()
		.selectMaritialStatus()
		.enterDateOfBirth()
		.clickOnMaleRadioButton()
		.clickOnSavePersonalDetails()
		.selectBloodGroup()
		.clickOnSaveCustomField();
		
		
		
	}
	
}
