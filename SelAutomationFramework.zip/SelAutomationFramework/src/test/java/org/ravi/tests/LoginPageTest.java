package org.ravi.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.ravi.driver.DriverManager;
import org.testng.annotations.Test;

public final class LoginPageTest extends BaseTest{

	private LoginPageTest() {

	}

	@Test
	public void test() {	
		System.out.println("Login page test start");
		DriverManager.getDriver().findElement(By.name("q")).sendKeys("Automation",Keys.ENTER);
		System.out.println("Login page end");

	}

}
