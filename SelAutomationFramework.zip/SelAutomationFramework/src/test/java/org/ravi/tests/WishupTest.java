package org.ravi.tests;

import org.assertj.core.api.Assertions;
import org.testng.annotations.Test;
import org.wishup.pages.Wishup_LoginPage;

public class WishupTest extends BaseTest {

	@Test
	public void loginTest() {
		
		
		
	}
}
