package org.ravi.tests;

import org.ravi.driver.Driver;
import org.ravi.reports.GenerateReport;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class BaseTest {

	protected BaseTest() {

	}

	@BeforeMethod
	protected void setUp() throws Exception {
		Driver.initDriver();
		
	}

	@AfterMethod()
	protected void tearDown() {
		Driver.quitDriver();
	}

}
