package org.wishup.test;

import org.assertj.core.api.Assertions;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.wishup.pages.WishUp_hirePage;
import org.wishup.pages.Wishup_CartPage;
import org.wishup.pages.Wishup_FeedbackPage;
import org.wishup.pages.Wishup_LoginPage;
import org.wishup.pages.Wishup_ProfilePage;
import org.wishup.pages.Wishup_createTask;
import org.wishup.pages.Wishup_dashBoardPage;


public class WishupTest extends BaseTest {

	
	/*
	 
	@Test
	public void loginTest() {
		
		String username = new Wishup_LoginPage()
		.sendKeysEmail()
		.sendKeysPassward()
		.clickOnloginBtn_2()
		.verifySuccessfulLogin();
		Assertions.assertThat(username)
		.isEqualTo("SwapG");
		
	}
	
	*/
	
	/*
	
	@Test(dataProviderClass = org.ravi.dataprovider.DataProviderClass.class, dataProvider = "readFile")
	public void verifyLoginWithMultipeCredentials(String email, String passward, String Status) {
		String urlAfterLogin = new Wishup_LoginPage().login(email,passward);
		if(Status.equalsIgnoreCase("Valid")) {
			Assertions.assertThat(urlAfterLogin).
			isEqualTo("https://app-dev.wishup.co/org/90013/my_daily_reports?fb_request=true");
			
			new Wishup_LoginPage().logOut();
		}
		else if(Status.equalsIgnoreCase("Invalid")) {
			Assertions.assertThat(urlAfterLogin).
			isNotEqualTo("https://app-dev.wishup.co/org/90013/my_daily_reports?fb_request=true");
		}
	}
	*/
	
	@Test
	public void verifyCreateTask() {
		new Wishup_LoginPage()
		.sendKeysEmail()
		.sendKeysPassward()
		.clickOnloginBtn_2();
		new Wishup_dashBoardPage().clickCreateTaskBtn();
		new Wishup_createTask()
		.giveTaskName("Wishup QA Assignment ")
		.giveTaskDescreption("Wishup QA Assignment ")
		.giveDuedate("August 13, 2022")
		.setFrequency()		
		.selectTeamMember()
		.selectCreateTaskBtn()
		.setCategory("Project Management")
		.sentSubCategory("Project Plan")
		.setStepsToTask("QA  Assignment")
		.clickSaveBtn();
		
	}
	
	/*
	@Test
	public void verifyFeedback() {
		new Wishup_LoginPage()
		.sendKeysEmail()
		.sendKeysPassward()
		.clickOnloginBtn_2();
		new Wishup_dashBoardPage().clickOnFeedbackBtn();
	String Str_feedback = new Wishup_FeedbackPage()
		.clickOnCreatFeedbackBtn()
		.clickOnGiveFeedbackBtn()
		.selectFromDate("August 6, 2022")
		.selectToDate("August 25, 2022")
		.giveStar()
		.sendMsg("you are creative")
		.clickSubmitBtn()
		.verifyfeedBack();
	Assertions.assertThat(Str_feedback)
	.isEqualTo("Feedback recorded successfully");
	}

	@Test
	public void verifyTotalVA() {
		new Wishup_LoginPage()
		.sendKeysEmail()
		.sendKeysPassward()
		.clickOnloginBtn_2();
	int VACount = new WishUp_hirePage()
		.clickHireBtnOnHomePage()
		.selectVACategory()
		.verifytotalVACount();
	Assertions.assertThat(VACount)
	.isEqualTo(101);
	}
	
	@Test
	public void verifyToolAndSkill() {
		new Wishup_LoginPage()
		.sendKeysEmail()
		.sendKeysPassward()
		.clickOnloginBtn_2();
		new WishUp_hirePage()
		.clickHireBtnOnHomePage()
		.selectVACategory()
		.searchSkills("MS Office CRM")
		.clickOnviewProfileBtn();
	String str_verifySkill=	new Wishup_ProfilePage()
	.clickOnTechSkills()
	.clickOnViewSkills()
	.verifySkills();
	Assertions.assertThat(str_verifySkill)
	.isEqualTo("CRM");
	String str_verifyTool = new Wishup_ProfilePage()
	.clickOnToolExperise()
	.veriyToolExpertise();
	Assertions.assertThat(str_verifyTool)
	.isEqualTo("MS Office");	
	}
	
	@Test
	public void verifyHireResources() {
		new Wishup_LoginPage()
		.sendKeysEmail()
		.sendKeysPassward()
		.clickOnloginBtn_2();
		new WishUp_hirePage()
		.clickHireBtnOnHomePage()
		.selectVACategory()
		.searchSkills("MS Office CRM")
		.clickOnviewProfileBtn();
		new Wishup_ProfilePage()
		.HiremeInprofile()
		.clickOnToggler()
		.clickOnSelectThisPlan();
		String str_PaymentStatus= new Wishup_CartPage()
		.selectCart()
		.selectTermsOfUseCheckBox()
		.clickOnProceedToPay()
		.clickOnRazorpay()
		.selectIframe()
		.enterEmail("swapnil.gejage@wishup.co")
		.payUsingCard()
		.selectCard()
		.enterCardNum("4242 4242 4242 4242")
		.enterCardExpiryNum("424")
		.enterCardCVVNum("424")
		.clickOnPaymentBtn()
		.completePayment();
		Assertions.assertThat(str_PaymentStatus).isEqualTo("paid");
	
	}
	*/

	}
	


