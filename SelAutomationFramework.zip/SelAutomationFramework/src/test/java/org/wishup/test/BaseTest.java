package org.wishup.test;

import org.ravi.driver.Driver;
import org.ravi.reports.GenerateReport;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

public class BaseTest {

	protected BaseTest() {

	}
	

	@BeforeClass
	protected void setUp() throws Exception {
		Driver.initDriver();
		
	}
	
	@BeforeMethod
  protected void openUrl() throws Exception {
		Driver.navigateToURL();
	}

	@AfterClass
	protected void tearDown() {
		Driver.quitDriver();
	}

}
