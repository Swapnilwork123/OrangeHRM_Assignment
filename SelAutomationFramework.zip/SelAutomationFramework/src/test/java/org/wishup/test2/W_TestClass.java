package org.wishup.test2;

import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import ogr.wishup.pages2.Wishup_LoginPage;

public class W_TestClass extends BaseTest {

	
//	@BeforeClass
//	public void objectInitialization() {
//		openBrowser();
//		objlogin = new Wishup_LoginPage(driver);
//		objcrTask = new Wishup_createTask(driver);
//		objFeedBack = new Wishup_FeedbackPage(driver);
//		objHire = new WishUp_hirePage(driver);
//		objProfile = new Wishup_ProfilePage(driver);
//		objCart = new Cart_byPageFactory(driver);
//		objDashBoard = new Wishup_dashBoardPage(driver);
//
//	}
//
//	@BeforeMethod
//	public void browsersSetup() {
//		// Maximize the window
//		driver.manage().window().maximize();
//		// Enter Url of web application
//		driver.get("https://app-dev.wishup.co");
//		// Implicit wait is added
//		// driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//
////		objlogin.sendKeysEmail();
////		objlogin.sendKeysPassward();
////		objlogin.clickOnloginBtn_2();
//	}
//
//	@Test
//	public void verifyLogin() {
//		objlogin.sendKeysEmail("swapnil.gejage@wishup.co");
//		objlogin.sendKeysPassward("Orchid@12746");
//		objlogin.clickOnloginBtn_2();
//		Assert.assertEquals(objlogin.verifySuccessfulLogin(), "SwapG");
//	}
//	
//	

	@Test(dataProviderClass = org.ravi.dataprovider.DataProviderClass.class, dataProvider = "readFile")
	public void Login2(String Username, String Passward, String DataStatus) {
		String Str_urlAfterLogin = objlogin.login(Username, Passward);
		if (DataStatus.equalsIgnoreCase("Valid")) {
			Assert.assertEquals(Str_urlAfterLogin,
					"https://app-dev.wishup.co/org/90013/my_daily_reports?fb_request=true");
			 objlogin.logOut();
		} else if (DataStatus.equalsIgnoreCase("Invalid")) {
			Assert.assertNotEquals(Str_urlAfterLogin,
					"https://app-dev.wishup.co/org/90013/my_daily_reports?fb_request=true");
		}

	}


/*
	@Test
	public void verifyCreateTask() {

		objDashBoard.clickCreateTaskBtn();
		objcrTask.giveTaskName("");
		objcrTask.giveTaskDescreption("");
		objcrTask.giveDuedate("");
		objcrTask.setFrequency();
		objcrTask.selectTeamMember();
		objcrTask.selectCreateTaskBtn();
		objcrTask.setCategory("");
		objcrTask.sentSubCategory("");
		objcrTask.setStepsToTask("");
		objcrTask.clickSaveBtn();
		

	}

	@Test
	public void verifyFeedBack() {

		objDashBoard.clickOnFeedbackBtn();
		objFeedBack.clickOnCreatFeedbackBtn();
		objFeedBack.clickOnGiveFeedbackBtn();
		objFeedBack.selectFromDate("");
		objFeedBack.selectToDate("");
		objFeedBack.giveStar();
		objFeedBack.sendMsg("");
		objFeedBack.clickSubmitBtn();
		Assert.assertEquals(objFeedBack.verifyfeedBack(), "Feedback recorded successfully");
	}

	@Test
	public void verifyTotalVA() {

		objHire.clickHireBtnOnHomePage();
		objHire.selectVACategory();
		objHire.verifytotalVACount();
		int vaCount = objHire.verifytotalVACount();
		System.out.println(vaCount);
		Assert.assertEquals(vaCount, 100);
	}

	@Test

	public void verifyToolSkills() {
//		objlogin.sendKeysEmail();
//		objlogin.sendKeysPassward();
//		objlogin.clickOnloginBtn_2();
		objHire.clickHireBtnOnHomePage();
		objHire.selectVACategory();
		objHire.searchSkills("");
		objHire.clickOnviewProfileBtn();
		objProfile.clickOnTechSkills();
		objProfile.clickOnViewSkills();
		Assert.assertEquals(objProfile.verifySkills(), "CRM");
		objProfile.clickOnToolExperise();
		Assert.assertEquals(objProfile.veriyToolExpertise(), "MS Office");
	}

	@Test
	public void verifyVAResourcesAvailable4hrsPerday() {
		objHire.clickHireBtnOnHomePage();
		objHire.selectVACategory();
		objHire.applyFourHrsFilter();
		objHire.clickOnviewProfileBtn();
		objProfile.clickOnSelectThisPlan();
		Assert.assertEquals(objProfile.verifyAvailablility(), "4 hrs/d");
	}

	@Test
	public void verifyHireResource()

	{

		objHire.clickHireBtnOnHomePage();
		objHire.selectVACategory();
		objHire.searchSkills("");
		objHire.clickOnviewProfileBtn();
		objProfile.HiremeInprofile();
		objProfile.clickOnToggler();
		objProfile.clickOnSelectThisPlan();
		objCart.selectCart();
		objCart.selectTermsOfUseCheckBox();
		objCart.clickOnProceedToPay();
		objCart.clickOnRazorpay();// not getting pay on Razorpay option, grtting pay via stripe
		objCart.selectIframe();
		objCart.enterEmail("");
		objCart.payUsingCard();
		objCart.selectCard();
		objCart.enterCardNum("");
		objCart.enterCardExpiryNum("");
		objCart.enterCardCVVNum("");
		objCart.clickOnPaymentBtn();
		// it will return the payment status
		String Str_paymentStatus = objCart.completePayment();
		Assert.assertEquals(Str_paymentStatus, "paid");
	
	}


//	@AfterClass
//	public void tearDown() {
//		closeBrowser();
//	}
*/
}
