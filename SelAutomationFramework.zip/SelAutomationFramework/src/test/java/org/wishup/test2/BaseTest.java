package org.wishup.test2;

import org.ravi.driver.Driver;
import org.ravi.reports.GenerateReport;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

import ogr.wishup.pages2.Cart_byPageFactory;
import ogr.wishup.pages2.WishUp_hirePage;
import ogr.wishup.pages2.Wishup_CartPage;
import ogr.wishup.pages2.Wishup_FeedbackPage;
import ogr.wishup.pages2.Wishup_LoginPage;
import ogr.wishup.pages2.Wishup_ProfilePage;
import ogr.wishup.pages2.Wishup_createTask;
import ogr.wishup.pages2.Wishup_dashBoardPage;



public class BaseTest {

	protected BaseTest() {

	}
	
	Wishup_LoginPage objlogin;
	Wishup_createTask objcrTask;
	Wishup_FeedbackPage objFeedBack;
	WishUp_hirePage objHire;
	Wishup_ProfilePage objProfile;
	Wishup_CartPage objCart;
	//Cart_byPageFactory objCart;
	Wishup_dashBoardPage objDashBoard;

	@BeforeClass
	protected void setUp() throws Exception {
		Driver.initDriver();
		objlogin =new Wishup_LoginPage();
		objcrTask = new Wishup_createTask();
		objFeedBack = new Wishup_FeedbackPage();
		objHire = new WishUp_hirePage();
		objProfile = new Wishup_ProfilePage();
		objCart = new Wishup_CartPage();
	//objCart = new Cart_byPageFactory(driver);
		objDashBoard = new Wishup_dashBoardPage();
	}
	
	@BeforeMethod  
  protected void openUrl() throws Exception {
		Driver.navigateToURL();
	}

	@AfterClass
	protected void tearDown() {
		Driver.quitDriver();
	}

}
