package ogr.wishup.pages2;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.ravi.enums.ExplicitWaitExpextecConditions;
import org.testng.Assert;

public class Wishup_LoginPage extends BaseClass {

	Logger logger = LogManager.getLogger(WishUp_hirePage.class);

//	public Wishup_LoginPage(WebDriver driver) {
//
//		this.driver = driver;
//	}

	// locator to select login button
	By by_LoginBtn_1 = By.xpath("//div[@class='right menu']//a[text()='Login']");
	// locator to select password text box
	By by_PasswardTextBox = By.name("password");
	// locator to select email text box
	By by_EmailTextBox = By.id("email");
	// locator to select login button_2
	By by_LoginBtn_2 = By.xpath("//input[@type='submit']");
	// locator to take username
	By by_username = By.xpath("//div[@class='right menu']//div[@class='ui simple dropdown item']");
	// locator to take error message from invalid login attempt
	By by_errormsg = By.xpath("//div[@class='ui error message']//div[@class='header']");

	By by_usernamedropdn = By.xpath("//div[@class='right menu']//div[@class='ui simple dropdown item']");

	By by_logout = By.xpath("//div[@class='ui navbar computer only tablet only grid']//a[contains(text(),'Logout')]");

	// click on login_1 button
	public void clickOnloginBtn_1() {
		click(by_LoginBtn_1, ExplicitWaitExpextecConditions.NONE);
		//driver.findElement(by_LoginBtn_1).click();
	}

	// Enter the email
	public void sendKeysEmail(String email) {
		//driver.findElement(by_EmailTextBox).sendKeys("swapnil.gejage@wishup.co");
		enterText(by_EmailTextBox, email, ExplicitWaitExpextecConditions.PRESENSCE);
		//enterData(by_EmailTextBox, "swapnil.gejage@wishup.co");
		logger.info("Email entered");
	}

	// enter the valid password
	public void sendKeysPassward(String passward) {
		enterText(by_PasswardTextBox, passward, ExplicitWaitExpextecConditions.PRESENSCE);
		//driver.findElement(by_PasswardTextBox).sendKeys("wishup123");
		logger.info("Passward entered");
	}

//	// Enter invalid email address
//	public void invalidEmail(String userName) {
//		enterData(by_EmailTextBox, userName);
//		//driver.findElement(by_EmailTextBox).sendKeys(userName);
//		logger.info("Invalid Email entered");
//	}
//
//	// Enter invalid password
//	public void invalidpassword(String password) {
//		enterData(by_PasswardTextBox, password);
//		//driver.findElement(by_PasswardTextBox).sendKeys(password);
//		logger.info("Invalid passward entered");
//	}

	// click on login_2 button
	public void clickOnloginBtn_2() {
		// driver.findElement(by_LoginBtn_2).click();
		click(by_LoginBtn_2, ExplicitWaitExpextecConditions.NONE);

//		JavascriptExecutor js = (JavascriptExecutor) driver;
//		js.executeScript("arguments[0].click();", "", driver.findElement(by_LoginBtn_2));
//		logger.info("clicked on login button");
//		System.out.println("logged in");
	}

	// This method will return the Username which will be used for assertion
	public String verifySuccessfulLogin() {
		String strUserName = driver.findElement(by_username).getText();
		logger.info("successful login varification");
		return strUserName;

	}

	// verify login functionality with invalid data
	public String verifyInvalidLogin() {
		String strErroMsg = driver.findElement(by_errormsg).getText();
		return strErroMsg;

	}

	// Avi
	public void logOut() {
		/*
		 * This method will helps user to logout any page
		 */
		// Identify and click on username
		click(by_usernamedropdn, ExplicitWaitExpextecConditions.NONE);
//		WebElement we_userName = driver.findElement(by_usernamedropdn);
//		we_userName.click();
		logger.info("Clicked on username profile ");
		// System.out.println("Clicked on username profile");
		// Reporter.log("Clicked on username profile ",true);
		// Identify and click on logout
		click(by_logout, ExplicitWaitExpextecConditions.NONE);

//		WebElement we_logoutButton = driver.findElement(by_logout);
//		we_logoutButton.click();
		logger.info("Clicked on logout button");
		// System.out.println("Clicked on logout button");
		// Reporter.log("Clicked on logout button ",true);
	}

	/*
	 * This method will perform login to the application by accepting parameters
	 * from test class input param: String email_Id & String password return:
	 * current url after login operation
	 */
	public String login(String Str_email, String Str_pwd) {
		// Enter valid email in the field
		enterText(by_EmailTextBox, Str_email, ExplicitWaitExpextecConditions.PRESENSCE);

		//driver.findElement(by_EmailTextBox).sendKeys(Str_email);
		logger.info("username entered");

		// Enter valid Password in the field
		enterText(by_PasswardTextBox, Str_pwd, ExplicitWaitExpextecConditions.PRESENSCE);

		//driver.findElement(by_PasswardTextBox).sendKeys(Str_pwd);
		logger.info("password entered");

		// Click on logIn button
		click(by_LoginBtn_2, ExplicitWaitExpextecConditions.NONE);

		//driver.findElement(by_LoginBtn_2).click();
		logger.info("click on the login button");
		String Str_currentURLAfterLogin = driver.getCurrentUrl();
		return Str_currentURLAfterLogin;
	}

}
