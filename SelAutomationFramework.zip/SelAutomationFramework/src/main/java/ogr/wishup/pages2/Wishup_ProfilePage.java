package ogr.wishup.pages2;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.ravi.enums.ExplicitWaitExpextecConditions;
import org.testng.Assert;

public class Wishup_ProfilePage extends BaseClass {
	
	Logger logger = LogManager.getLogger(Wishup_ProfilePage.class);
	

	By by_techSkills = By.xpath("//span[text()='Technical Skills']");
	// locator to view technical skill
	By by_viewSkills = By.xpath("//div[contains(text(),'View all skills')]");
	// locator to view more skill
	By by_skillSet = By.xpath("//div[@class='more-skills']");
	// locator to select tool expertise option
	By by_toolExp = By.xpath("//span[text()='Tool Expertise']");
	// locator to get the tool
	By by_tools = By.xpath("//div[@class='top-tools tool-names']");
	// locator to select the plan button
	By by_selectThisPlanButton = By.xpath("(//span[@class='select-popular-text'])[2]");
	// locator to select toggler
	By by_toggler = By.id("toggler");
	// locator to select this plan button for half day
	By by_selectThisPlanButtonforhalfday = By.xpath("//a[@class='half-url']//span[@class='select-popular-text']");
	// locator to click on hire me button
	By by_hireMeBtn = By.xpath("//div[@class='container-fluid']//a[@class='hire-me-button']");
	// locator to get the text
	By by_available = By.xpath("(//div[text()='4 hrs/d'])[1]");

	// Method to click on techSkill
	public void clickOnTechSkills() {
		click(by_techSkills, ExplicitWaitExpextecConditions.NONE);

		//clickOn(by_techSkills);
		//driver.findElement(by_techSkills).click();
		logger.info("clicked on tech skill");
	}

	// Method to Click on view skill
	public void clickOnViewSkills() {
		click(by_viewSkills, ExplicitWaitExpextecConditions.NONE);

		//clickOn(by_viewSkills);
		//driver.findElement(by_viewSkills).click();
		logger.info("clicked on view skill");
	}

	// Method to verify the skills
	public String verifySkills() {
		String strSkill = driver.findElement(by_skillSet).getText();
		System.out.println(strSkill);
		return strSkill;

	}

	// Method to Click on tool expertise
	public void clickOnToolExperise() {
		click(by_toolExp, ExplicitWaitExpextecConditions.NONE);

		//clickOn(by_toolExp);
		//driver.findElement(by_toolExp).click();
		logger.info("clicked on tool expertise");
	}

	// Method to Verify tool expertise
	public String veriyToolExpertise() {
		String strTools = driver.findElement(by_tools).getText();
		System.out.println(strTools);
		return strTools;
	}

	// Method to select the 4hr plan
	public void selectPlan(WebDriver driver) {
		boolean result = driver.findElement(by_selectThisPlanButton).isEnabled();
		Assert.assertTrue(result);
	}

	// Method to Select toggler
	public void clickOnToggler() {
		click(by_toggler, ExplicitWaitExpextecConditions.NONE);

		//clickOn(by_toggler);
		//driver.findElement(by_toggler).click();
		logger.info("clicked on toggler");
	}

	// Method to Click on select this plan under half day section
	public void clickOnSelectThisPlan() {
		click(by_selectThisPlanButtonforhalfday, ExplicitWaitExpextecConditions.NONE);

		//clickOn(by_selectThisPlanButtonforhalfday);
		//driver.findElement(by_selectThisPlanButtonforhalfday).click();
	}

	// Method to click on hire me profile button
	public void HiremeInprofile() {
		click(by_hireMeBtn, ExplicitWaitExpextecConditions.NONE);

		//clickOn(by_hireMeBtn);
		//driver.findElement(by_hireMeBtn).click();
		logger.info("clicked on hire me button");
	}

	// Method to This method return 4hrsper day plan
	public String verifyAvailablility()

	{
		String stractualplan = driver.findElement(by_available).getText();
		System.out.println(stractualplan);
		return stractualplan;
	}

	
}
