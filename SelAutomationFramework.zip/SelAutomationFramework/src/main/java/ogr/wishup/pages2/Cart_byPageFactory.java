package ogr.wishup.pages2;

import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Cart_byPageFactory extends BaseClass {

	
	// locator for alreadyadded to get the text
	@FindBy (xpath="//h3[text()='You have already added this VA to cart.']")
	WebElement by_alreadyadded;

	// locator for goto cart button
	@FindBy (xpath="//button[contains(text(),'Go to cart')]")
	WebElement by_goToCart;

	// locator to click on OK button
	@FindBy (xpath="//button[contains(text(),'Ok')]")
	WebElement by_alreadyAdded_Ok;
	// click on cart
	@FindBy (xpath="//a[@class='cart-icon']")
	WebElement by_Cart;
	// locator to accept terms of use
	@FindBy (xpath="//input[@type='checkbox']/following::label[text()='I agree to the ']")
	WebElement by_termsOfUse;
	// locator to select proceed to pay
	@FindBy (xpath="//input[@type='submit']")
	WebElement by_proceedToPay;
	
	// locator to select razorpay option
	@FindBy (xpath="//button[text()='Pay via Razorpay']")
	WebElement by_paymentMode_Razorpay;
	
	// locator to select iframe
	@FindBy (xpath="//iframe[@class='razorpay-checkout-frame']")
	WebElement by_iframe;
	 
	// locator to enter the textbox to emailbox	
	@FindBy (xpath="//input[@id='email']")
	WebElement by_emailTextbox;
 	// locator to select pay using card option
	@FindBy (xpath="//div[@role='button']")
	WebElement by_payUsingCardBtn;
	 
	// locator to select card button
	@FindBy (xpath="//button[@method='card']")
	WebElement by_card;
	// locator to enter card number
	@FindBy (id="card_number")
	WebElement by_cardNo;
	// locator to enter card expiry
	@FindBy (id="card_expiry")
	WebElement by_expiry;
	// locator to enter card cvv
	@FindBy (id="card_cvv")
	WebElement by_cvvNo;
	// locator to select pay button
	@FindBy (xpath="//div[@role='button']")
	WebElement by_payBtn;
	// locator to select pay button
	@FindBy (xpath="//button[text()='Success']")
	WebElement by_successBtn;
	// locator to check payment status
	@FindBy (xpath="//div[@class='ui olive small top right attached label']")
	WebElement by_payStaus;
	
	static Logger logger = LogManager.getLogger(Cart_byPageFactory.class);  
	
 	public Cart_byPageFactory(WebDriver driver) 
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	// This method will check plan added to cart or not and act acordingly
	String strAdress1, strAdress2;

	public String[] selectCart() {
		String strSuccessmsg =by_alreadyadded.getText();
		// if plan is already added then go to cart
		if (strSuccessmsg.equals("Plan is added to the cart!")) {
			by_goToCart.click();
			
			logger.info("clicked on go to cart button");
			strAdress1 = driver.getCurrentUrl();
		} else {

			by_alreadyAdded_Ok.click();
			logger.info("clicked on added ok button");
			strAdress2 = driver.getCurrentUrl();

		}

		// Method toClick on add to cart
		by_Cart.click();
		logger.info("clicked on cart");
		
		String strURL[] = { strAdress1, strAdress2 };
		return strURL;

	}

	// Click on terms of use checkbox
	public void selectTermsOfUseCheckBox() {

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", by_termsOfUse);
		logger.info("clicked on terms of use check box");
	}

	// Click on proceed to pay
	public void clickOnProceedToPay() {
		by_proceedToPay.click();

		logger.info("clicked on proceed to pay");
	}

	// Click on razorpay button
	public void clickOnRazorpay() {
		by_paymentMode_Razorpay.click();
		logger.info("clicked on razorpay button");
	}

	// Select the frame by iframe handling
	public void selectIframe() {

		driver.switchTo().frame(by_iframe);
		logger.info("switched to iframe");
	}

	// Enter email in email text box
	public void enterEmail() {
		by_emailTextbox.sendKeys("swapnil.gejage@wishup.co");
		logger.info("enered the Email");
	}

	// Pay using card
	public void payUsingCard() {
		by_payUsingCardBtn.click();
		logger.info("clicked pay using card  button");
	}

	// Select card for payment
	public void selectCard() {
		by_card.click();
		logger.info("clicked on card button");

	}

	// Enter card number
	public void enterCardNum() {
		by_cardNo.sendKeys("4242 4242 4242 4242");
		logger.info("enter card number");

	}

	// Enter card expiry number
	public void enterCardExpiryNum() {
		by_expiry.sendKeys("424");
		logger.info("enter card expiry number");

	}

	// Enter card CVV number
	public void enterCardCVVNum() {
		by_cvvNo.sendKeys("424");
		logger.info("entered the cvv num of card");
	}

	public void clickOnPaymentBtn() {
		by_payBtn.click();
		logger.info("clicked on payment button");
	}

	// This method complete the payment operation and return the payment status
	public String completePayment() {
		String strparentWindowAdress = driver.getWindowHandle();
		Set<String> strChildWindowAdress = driver.getWindowHandles();
		for (String childwindow : strChildWindowAdress) {
			if (!childwindow.equals(strparentWindowAdress)) {
				driver.switchTo().window(childwindow);
				logger.info("switched to child window");
				by_successBtn.click();
				logger.info("clicked on success button");
				driver.switchTo().window(strparentWindowAdress);
				logger.info("switched to parent window");
			}
		}
		// Gives the status of payment
		String strPaymentStatus = by_payStaus.getText();
		System.out.println(strPaymentStatus);
		return strPaymentStatus;
	}


}
