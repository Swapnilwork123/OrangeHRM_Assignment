package ogr.wishup.pages2;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.ravi.enums.ExplicitWaitExpextecConditions;

public class Wishup_createTask extends BaseClass {
	static Logger logger = LogManager.getLogger(Wishup_createTask.class);  
	
	
	
	//By by_CreateTaskBtn =By.xpath("//a[@class='ui create_task_button_desktop  circular button']");
	// locator to enter the task name
	By by_TaskName =By.xpath("//div[@class='ui twelve wide column']//input[@name='name']");
	// locator to enter task description
	By by_TaskDiscreption =By.xpath("//trix-editor[@input='task_details']");
	// locator to enter due date
	By by_DueDate =By.xpath("//div[@class='ui computer tablet only grid']//input[@placeholder='Date/Time']");
	// locator to set the frequency
	By by_frequency =By.xpath("//div[@class='ui radio checkbox checked']");
	// locator to team memeber to whom task has to be assigned
	By by_teamMember= By.xpath("//div[@class='ui computer tablet only grid']//div[contains(text(),'SwapG')]");
   // locator to select create task button
	By by_createTaskButton =By.xpath("//div[@class='ui twelve wide column']// button[@type='submit']");
   // locator to select category
	By by_category =By.xpath("//input[@class='search']");
   // locator to select subcategory
	By by_subcategory =By.xpath("//input[@list='sub_categories']");
   // locator to enter the steps
	By by_steps = By.xpath("// trix-editor[@toolbar='trix-toolbar-1']");   
   // locator to enter the links
	By link = By.xpath("//input[@name='links']");
	// locator to select save details button
    By saveDeatilsButton = By.xpath("//div[@class='ui computer tablet only grid']//form[@class='ui form']//button[text()=' Save Details']");

// Method to Enter task name
public void giveTaskName(String taskName) {
	//driver.findElement(by_TaskName).sendKeys("Wishup QA Assignment ");
	enterText(by_TaskName, taskName, ExplicitWaitExpextecConditions.PRESENSCE);

	//enterData(by_TaskName, "Wishup QA Assignment ");
	logger.info("Task name entered");
}
// Enter task description
public void giveTaskDescreption(String taskDescreption) {
	enterText(by_TaskDiscreption, taskDescreption, ExplicitWaitExpextecConditions.PRESENSCE);

	//driver.findElement(by_TaskDiscreption).sendKeys("Wishup QA Assignment ");
	//enterData(by_TaskDiscreption, "Wishup QA Assignment ");
	logger.info("Task description entered");
}
// Method to Enter due date
public void giveDuedate(String dueDate)  {
	enterText(by_DueDate, dueDate, ExplicitWaitExpextecConditions.PRESENSCE);

	//driver.findElement(by_DueDate).sendKeys("August 13, 2022");
	//enterData(by_DueDate, "August 13, 2022");
	logger.info("Due date entered entered");
}
// Method to Set the frequency
public void setFrequency() {
	//driver.findElement(by_frequency).click();
	click(by_frequency, ExplicitWaitExpextecConditions.NONE);

	//clickOn(by_frequency);
	logger.info("Frequency is set");
}
// Method to Select team member
public void selectTeamMember() {
	//driver.findElement(by_teamMember).click();
	click(by_teamMember, ExplicitWaitExpextecConditions.NONE);

	//clickOn(by_teamMember);
	logger.info("team member is selected");
}

// Method to Click on create task button
public void selectCreateTaskBtn() {
	//driver.findElement(by_createTaskButton).click();	
	click(by_createTaskButton, ExplicitWaitExpextecConditions.NONE);

	//clickOn(by_createTaskButton);
	logger.info("clicked on create task button");
}

// Method to Enter category
public void setCategory(String category) {
	enterText(by_category, category, ExplicitWaitExpextecConditions.PRESENSCE);

	//driver.findElement(by_category).sendKeys("Project Management");	
	//enterData(by_category, "Project Management");
	logger.info("Set the category");
}
// Method toEnter sub category
public void sentSubCategory(String subCategory) {
	enterText(by_subcategory, subCategory, ExplicitWaitExpextecConditions.PRESENSCE);

	//enterData(by_subcategory, "Project Plan");
	//driver.findElement(by_subcategory).sendKeys("Project Plan");
	logger.info("Select sub category");
}
// Method to Enter the steps
public void setStepsToTask(String setStep) {
	enterText(by_steps, setStep, ExplicitWaitExpextecConditions.PRESENSCE);
	//enterData(by_steps, "QA  Assignment");
	//driver.findElement(by_steps).sendKeys("QA  Assignment");
	logger.info("set steps to task");
}


// Method to Click on save button
public void clickSaveBtn() {
	click(saveDeatilsButton, ExplicitWaitExpextecConditions.NONE);

	//clickOn(saveDeatilsButton);
	//driver.findElement(saveDeatilsButton).click();	
	logger.info("Click on saveButton");
}
}
