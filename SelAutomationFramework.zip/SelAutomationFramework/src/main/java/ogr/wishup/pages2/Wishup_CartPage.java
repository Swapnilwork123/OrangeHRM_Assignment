package ogr.wishup.pages2;

import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.ravi.enums.ExplicitWaitExpextecConditions;

public class Wishup_CartPage extends BaseClass {

  static Logger logger = LogManager.getLogger(Wishup_CartPage.class);
	

	// locator for alreadyadded to get the text
	By by_alreadyadded = By.xpath("//h3[text()='You have already added this VA to cart.']");
	// locator for goto cart button
	By by_goToCart = By.xpath("//button[contains(text(),'Go to cart')]");
	// locator to click on OK button
	By by_alreadyAdded_Ok = By.xpath("//button[contains(text(),'Ok')]");
	// click on cart
	By by_Cart = By.xpath("//a[@class='cart-icon']");
	// locator to accept terms of use
	By by_termsOfUse = By.xpath("//input[@type='checkbox']/following::label[text()='I agree to the ']");
	// locator to select proceed to pay
	By by_proceedToPay = By.xpath("//input[@type='submit']");
	// locator to select razorpay option
	By by_paymentMode_Razorpay = By.xpath("//button[text()='Pay via Razorpay']");
	// locator to select iframe
	By by_iframe = By.xpath("//iframe[@class='razorpay-checkout-frame']");
	// locator to enter the textbox to emailbox
	By by_emailTextbox = By.xpath("//input[@id='email']");
	// locator to select pay using card option
	By by_payUsingCardBtn = By.xpath("//div[@role='button']");
	// locator to select card button
	By by_card = By.xpath("//button[@method='card']");
	// locator to enter card number
	By by_cardNo = By.id("card_number");
	// locator to enter card expiry
	By by_expiry = By.id("card_expiry");
	// locator to enter card cvv
	By by_cvvNo = By.id("card_cvv");
	// locator to select pay button
	By by_payBtn = By.xpath("//div[@role='button']");
	// locator to select pay button
	By by_successBtn = By.xpath("//button[text()='Success']");
	// locator to check payment status
	By by_payStaus = By.xpath("//div[@class='ui olive small top right attached label']");

	// This method will check plan added to cart or not and act acordingly
	String strAdress1, strAdress2;

	public String[] selectCart() {
		String strSuccessmsg = driver.findElement(by_alreadyadded).getText();
		// if plan is already added then go to cart
		if (strSuccessmsg.equals("Plan is added to the cart!")) {
			driver.findElement(by_goToCart).click();
			strAdress1 = driver.getCurrentUrl();
		} else {
			driver.findElement(by_alreadyAdded_Ok).click();
			strAdress2 = driver.getCurrentUrl();
		}

		// Method toClick on add to cart
		driver.findElement(by_Cart).click();

		String strURL[] = {strAdress1, strAdress2};
		return strURL;

	}

	// Click on terms of use checkbox
	public void selectTermsOfUseCheckBox() {

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", driver.findElement(by_termsOfUse));
		logger.info("select terms of use check box");
	}

	// Click on proceed to pay
	public void clickOnProceedToPay() {
		click(by_proceedToPay, ExplicitWaitExpextecConditions.NONE);

		//clickOn(by_proceedToPay);;
		//driver.findElement(by_proceedToPay).click();
		logger.info("click on proceed to pay button");
	}

	// Click on razorpay button
	public void clickOnRazorpay() {
		click(by_paymentMode_Razorpay, ExplicitWaitExpextecConditions.NONE);

		//clickOn(by_paymentMode_Razorpay);
		//driver.findElement(by_paymentMode_Razorpay).click();
		logger.info("clicked on razor pay button");
	}

	// Select the frame by iframe handling
	public void selectIframe() {

		driver.switchTo().frame(driver.findElement(by_iframe));
		logger.info("found the iframe and switched on it");
	}

	// Enter email in email text box
	public void enterEmail(String Email) {
		enterText(by_emailTextbox, Email, ExplicitWaitExpextecConditions.PRESENSCE);

		//enterData(by_emailTextbox, "swapnil.gejage@wishup.co");
	//	driver.findElement(by_emailTextbox).sendKeys("swapnil.gejage@wishup.co");
		logger.info("entered the Email");
	}

	// Pay using card
	public void payUsingCard() {
		click(by_payUsingCardBtn, ExplicitWaitExpextecConditions.NONE);

		//clickOn(by_payUsingCardBtn);
		//driver.findElement(by_payUsingCardBtn).click();
		logger.info("clicked on pay using card buttton");
	}

	// Select card for payment
	public void selectCard() {
		click(by_card, ExplicitWaitExpextecConditions.NONE);

		//clickOn(by_card);
		//driver.findElement(by_card).click();
		logger.info("select the card");
	}

	// Enter card number
	public void enterCardNum(String cardNum) {
		enterText(by_cardNo, cardNum, ExplicitWaitExpextecConditions.PRESENSCE);

		//enterData(by_cardNo, "4242 4242 4242 4242");
		//driver.findElement(by_cardNo).sendKeys("4242 4242 4242 4242");
		logger.info("entered the card number");
	}

	// Enter card expiry number
	public void enterCardExpiryNum(String cardExpiryNum) {
		enterText(by_expiry, cardExpiryNum, ExplicitWaitExpextecConditions.PRESENSCE);
		//enterData(by_expiry, "424");
		//driver.findElement(by_expiry).sendKeys("424");
		logger.info("entered the card expiry number");
	}

	// Enter card CVV number
	public void enterCardCVVNum(String CardCVV) {
		enterText(by_expiry, CardCVV, ExplicitWaitExpextecConditions.PRESENSCE);
		//enterData(by_cvvNo, "424");
		//driver.findElement(by_cvvNo).sendKeys("424");
		logger.info("entered the card cvv number");
	}

	public void clickOnPaymentBtn() {
		click(by_payBtn, ExplicitWaitExpextecConditions.NONE);

		//clickOn(by_payBtn);
		//driver.findElement(by_payBtn).click();
		logger.info("Clicked on payment button");
	}

	// This method complete the payment operation and return the payment status
	public String completePayment() {
		String strparentWindowAdress = driver.getWindowHandle();
		Set<String> strChildWindowAdress = driver.getWindowHandles();
		for (String childwindow : strChildWindowAdress) {
			if (!childwindow.equals(strparentWindowAdress)) {
				driver.switchTo().window(childwindow);
				logger.info("switched to the childwindow");
				driver.findElement(by_successBtn).click();
				logger.info("clicked on success button");
				driver.switchTo().window(strparentWindowAdress);
				logger.info("switched to parent window");
			}
		}
		
		// Gives the status of payment
		String strPaymentStatus = driver.findElement(by_payStaus).getText();
		System.out.println(strPaymentStatus);
		logger.info("verify the payment status");
		return strPaymentStatus;
		
	}

}
