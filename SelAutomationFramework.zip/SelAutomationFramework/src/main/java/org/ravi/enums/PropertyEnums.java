package org.ravi.enums;

public enum PropertyEnums {

		URL,
		BROWSER
}
