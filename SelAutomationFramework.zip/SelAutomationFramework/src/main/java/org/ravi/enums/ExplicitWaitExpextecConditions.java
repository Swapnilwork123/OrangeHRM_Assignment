package org.ravi.enums;

public enum ExplicitWaitExpextecConditions {

	CLICKABLE,
	PRESENSCE,
	VISIBILE,
	NONE
	
}
