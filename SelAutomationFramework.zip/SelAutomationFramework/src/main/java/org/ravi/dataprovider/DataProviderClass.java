package org.ravi.dataprovider;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.ravi.constants.FrameworkConstants;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DataProviderClass {



	@Test (dataProvider="readFile")
	public void getCredentials(String Username, String Password, String Status) {
		System.out.println(Username+" "+ Password+" "+ Status);
	}
	
	@DataProvider
	public Object[][] readFile() throws IOException {
		
		//FileInputStream fis = new FileInputStream("E:\\workData\\excleData.xlsx");
		FileInputStream fis = new FileInputStream(FrameworkConstants.getResourcePath()+"/executables/excleData.xlsx");
		
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
	    XSSFSheet sheet = workbook.getSheet("OrangeHRMData");
	    int  rowCount = sheet.getLastRowNum();
	    System.out.println(rowCount);
	    
	    int coloumCount = sheet.getRow(0).getLastCellNum();
	    System.out.println(coloumCount);
	    
	    Object [][] data = new Object[rowCount][coloumCount];
	    
	    for(int i=1; i<=rowCount; i++) {
	    	for(int j=0; j<coloumCount; j++) {
	    		data [i-1][j]= sheet.getRow(i).getCell(j).getStringCellValue();
	    	}
	    }
	 
	    return data;
	}
	
	
	

}
