package org.wishup.pages;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.ravi.enums.ExplicitWaitExpextecConditions;
import org.testng.Assert;

public class Wishup_FeedbackPage extends BasePage { 
	Logger logger = LogManager.getLogger(Wishup_FeedbackPage.class);
	

	
	//By Feedbackbutton = By.xpath("//div[@class='side-menu-label']//span[text()='Feedback']");
	// locator to select create feedback button
    By by_Createfeedbackbtn =By.xpath("//div[@class='ui workspace thirteen wide column']//a[@class='ui basic right floated circular button']");
    // locator to select give feedback button
    By by_Givefeedbackbtn =By.xpath("//div[@class='ui client_dashboard computer only grid']//a[@class='ui basic  assign_task button']");
    // locator to select "From" date
    By by_Fromdate =By.cssSelector("[id='slot_start_date'] input");
    // locator to select to date
    By by_Todate =By.cssSelector("div[id='slot_end_date'] input");
    // locator to enter the feedback message
    By by_Msg= By.name("message");
    // locator to give star rating to the member
    By by_Star =By.xpath("//i[@class=\"star icon\"][5]");
    // locator to select submit feedback button
    By by_Submitbutton=By.xpath("//div[@type='submit']");
    // locator to get the feed back success message
    By by_Successmsg= By.xpath("//div[@class='ui positive message']");
    
   
    // Method to click on create feedback button
    public Wishup_FeedbackPage clickOnCreatFeedbackBtn() {
    	click(by_Createfeedbackbtn, ExplicitWaitExpextecConditions.NONE);
    	//clickOn(by_Createfeedbackbtn);
    	//driver.findElement(by_Createfeedbackbtn).click();
    	logger.info("clicked on create feedback button");
   return this;
    }
    
    //Method to click on give feedback button
    public Wishup_FeedbackPage clickOnGiveFeedbackBtn() {
    	click(by_Givefeedbackbtn, ExplicitWaitExpextecConditions.NONE);
    	logger.info("clicked on give feedback button");
    	return this;
    }
    // Method to Select from date
    public Wishup_FeedbackPage selectFromDate(String fromDate) {
    	enterText(by_Fromdate, fromDate, ExplicitWaitExpextecConditions.PRESENSCE);
    	//enterData(by_Fromdate, "August 6, 2022");
    	//driver.findElement(by_Fromdate).sendKeys("August 6, 2022");
    	logger.info("enter from date");
    	return this;
    }
    // Method to Select to date
    public Wishup_FeedbackPage selectToDate(String toDate) {
    	enterText(by_Todate, toDate, ExplicitWaitExpextecConditions.PRESENSCE);

    	//enterData(by_Todate, "August 25, 2022");
    	//driver.findElement(by_Todate).sendKeys("August 25, 2022");
    	logger.info("enter to date");
    	return this;
    }
    
    // Method to give star rating
    public Wishup_FeedbackPage giveStar() {
    	click(by_Star, ExplicitWaitExpextecConditions.NONE);

    	//clickOn(by_Star);
    	//driver.findElement(by_Star).click();
    	logger.info("given rating in stars");
    	return this;
    }
    // Method to Enter message
    public Wishup_FeedbackPage sendMsg(String message) {
    	enterText(by_Msg, message, ExplicitWaitExpextecConditions.PRESENSCE);

    	//enterData(by_Msg, "you are creative");
    	//driver.findElement(by_Msg).sendKeys("you are creative");
    	logger.info("message entered");
    	return this;
    }
    // Method to Click on submit button
    public Wishup_FeedbackPage clickSubmitBtn() {
    	click(by_Submitbutton, ExplicitWaitExpextecConditions.NONE);

    	//clickOn(by_Submitbutton);
    	//driver.findElement(by_Submitbutton).click();
    	logger.info("clicked on submit button");
    	return this;
    }	
     
    // Method to Verify the feedback given successfully
    public String verifyfeedBack() {
    	
    	String strFeedbackMsg =driver.findElement(by_Successmsg).getText();
    	return strFeedbackMsg;
 			
    }
}
