package org.wishup.pages;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.ravi.driver.DriverManager;
import org.ravi.enums.ExplicitWaitExpextecConditions;
import org.ravi.reports.ExtentLogger;
import org.testng.Assert;

public class Wishup_LoginPage extends BasePage {

	
	Logger logger = LogManager.getLogger(Wishup_LoginPage.class);

//	public Wishup_LoginPage(WebDriver driver) {
//
//		this.driver = driver;
//	}

	// locator to select login button
	By by_LoginBtn_1 = By.xpath("//div[@class='right menu']//a[text()='Login']");
	// locator to select password text box
	By by_PasswardTextBox = By.name("password");
	// locator to select email text box
	By by_EmailTextBox = By.id("email");
	// locator to select login button_2
	By by_LoginBtn_2 = By.xpath("//input[@type='submit']");
	// locator to take username
	By by_username = By.xpath("//div[@class='right menu']//div[@class='ui simple dropdown item']");
	// locator to take error message from invalid login attempt
	By by_errormsg = By.xpath("//div[@class='ui error message']//div[@class='header']");

	By by_usernamedropdn = By.xpath("//div[@class='right menu']//div[@class='ui simple dropdown item']");

	By by_logout = By.xpath("//div[@class='ui navbar computer only tablet only grid']//a[contains(text(),'Logout')]");


	// Enter the email
	public Wishup_LoginPage sendKeysEmail() {
		DriverManager.getDriver().manage().window().maximize();
		enterText(by_EmailTextBox, "swapnil.gejage@wishup.co", ExplicitWaitExpextecConditions.PRESENSCE);
		ExtentLogger.pass("Email Entered");
		return this;
	}

	// enter the valid password
	public Wishup_LoginPage sendKeysPassward() {
		enterText(by_PasswardTextBox, "Orchid@12746", ExplicitWaitExpextecConditions.NONE);
		ExtentLogger.pass("Password Entered");
		return this;
	}

	// click on login_2 button
	public Wishup_LoginPage clickOnloginBtn_2() {
		// driver.findElement(by_LoginBtn_2).click();
		click(by_LoginBtn_2, ExplicitWaitExpextecConditions.NONE);
//		JavascriptExecutor js = (JavascriptExecutor) driver;
//		js.executeScript("arguments[1].click();", "", driver.findElement(by_LoginBtn_2));
//		logger.info("clicked on login button");
//		System.out.println("logged in");
		return this;
	}

	// This method will return the Username which will be used for assertion
	public String verifySuccessfulLogin() {
		String strUserName = DriverManager.getDriver().findElement(by_username).getText();
		logger.info("successful login varification");
		return strUserName;
	}

	// verify login functionality with invalid data
	public String verifyInvalidLogin() {
		String strErroMsg = driver.findElement(by_errormsg).getText();
		return strErroMsg;
	}

	// Below method does logout
	public Wishup_LoginPage logOut() {
		/*
		 * This method will helps user to logout any page
		 */
		// Identify and click on username
		
		click(by_usernamedropdn, ExplicitWaitExpextecConditions.NONE);
		logger.info("Clicked on username profile ");
	
		// Identify and click on logout
		click(by_logout, ExplicitWaitExpextecConditions.NONE);
		logger.info("Clicked on logout button");
		return this;
	}

	/*
	 * This method will perform login to the application by accepting parameters
	 * from test class input param: String email_Id & String password return:
	 * current url after login operation
	 */
	public String login(String Str_email, String Str_pwd) {
		// Enter valid email in the field
		enterText(by_EmailTextBox, Str_email, ExplicitWaitExpextecConditions.PRESENSCE);

		//driver.findElement(by_EmailTextBox).sendKeys(Str_email);
		logger.info("username entered");
		// Enter valid Password in the field		
		enterText(by_PasswardTextBox, Str_pwd, ExplicitWaitExpextecConditions.PRESENSCE);
		logger.info("password entered");
		// Click on logIn button
		click(by_LoginBtn_2, ExplicitWaitExpextecConditions.NONE);

		//driver.findElement(by_LoginBtn_2).click();
		logger.info("click on the login button");
		String Str_currentURLAfterLogin = DriverManager.getDriver().getCurrentUrl();
		System.out.println("driver worked");
		return Str_currentURLAfterLogin;
	}

}
