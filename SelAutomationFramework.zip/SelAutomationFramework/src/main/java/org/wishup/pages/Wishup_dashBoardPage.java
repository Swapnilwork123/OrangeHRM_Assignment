package org.wishup.pages;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.ravi.enums.ExplicitWaitExpextecConditions;

public class Wishup_dashBoardPage extends BasePage{
	
	static Logger logger = LogManager.getLogger(Wishup_dashBoardPage.class);
	
//public  Wishup_dashBoardPage(WebDriver driver) {
//	
//	this.driver=driver;
//}
	// locator to select create task button
	By by_CreateTask =By.xpath("//a[@class='ui create_task_button_desktop  circular button']");
	// locator to select feedback button
	By by_Feedbackbutton = By.xpath("//div[@class='side-menu-label']//span[text()='Feedback']");
	
	By by_userNameDropDown = By.xpath("//div[@class='ui top_menu secondary fluid pointing large menu']//div[@class='ui simple dropdown item']");
	
	By by_logOutBtn = By.xpath("//div[@class='ui top_menu secondary fluid pointing large menu']//a[text()='Logout']");
	// Method to Click on create task button
	public Wishup_dashBoardPage clickCreateTaskBtn() {
		click(by_CreateTask, ExplicitWaitExpextecConditions.NONE);
		//clickOn(by_CreateTask);
		//driver.findElement(by_CreateTask).click();
		logger.info("click on create task button");
		return this;
	}
	// Method to Click on feedback button
    public Wishup_dashBoardPage clickOnFeedbackBtn() {
		click(by_Feedbackbutton, ExplicitWaitExpextecConditions.NONE);

    	//clickOn(by_Feedbackbutton);
    	//driver.findElement(by_Feedbackbutton).click();
		logger.info("click on feedback button");
		return this;

    }
    
    public void moveToUserDropDown() {
    	Actions act = new Actions(driver);
    	act.moveToElement(driver.findElement(by_userNameDropDown)).perform();
		logger.info("moved to user dropdown");

    }
    
    public void clickOnLogout() {
    	//clickOn(by_logOutBtn);
    	click(by_logOutBtn, ExplicitWaitExpextecConditions.NONE);
    	//driver.findElement(by_logOutBtn).click();
		logger.info("click on logout button");

    }
    
    
   
}
