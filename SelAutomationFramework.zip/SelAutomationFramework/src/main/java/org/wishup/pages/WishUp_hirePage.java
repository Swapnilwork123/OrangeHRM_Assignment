package org.wishup.pages;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.ravi.enums.ExplicitWaitExpextecConditions;
import org.testng.Assert;

public class WishUp_hirePage extends BasePage {

	Logger logger = LogManager.getLogger(WishUp_hirePage.class);
	
	// locator to select hire button
	By by_hireBtnHomePage =By.xpath("//div[@class='ui navbar computer only tablet only grid']//a[@class='ui blue hiring_button button']");
	// locator to select VA category
	By by_VACategory = By.xpath("(//span[text()='virtual assistant'])[1]");
	// locator for slider
	By by_slider =By.className("slider");
	// locator to view profile
	By by_viewProfile = By.xpath("(//button[@class='profile-button'])[1]");
	// locator for search bar
	By by_searchBar =By.id("searchbar");
	// locator for select virtual assistant
	By by_allprofile = By.xpath("//form[@id='form']/following::div[normalize-space() ='virtual assistant']");
	// locator to select next button
	By by_next = By.xpath("//div[@class='page-section']/button[@class='page-next']");
	// locator to select technical skills
	By by_techSkills =By.xpath("//span[text()='Technical Skills']");
	// locator to view technical skill
	By by_viewSkills =By.xpath("//div[contains(text(),'View all skills')]");
	// locator to view more skill
	By by_skillSet =By.xpath("//div[@class='more-skills']");
	// locator to select tool expertise option
	By by_toolExp = By.xpath("//span[text()='Tool Expertise']");
	// locator to get the tool
	By tools = By.xpath("//div[@class='top-tools tool-names']");
    // locator to select the plan button
	By selectThisPlanButton = By.xpath("(//span[@class='select-popular-text'])[2]");	
	// locator to select toggler
	By toggler = By.id("toggler");
	// locator to select this plan button for half day
	By selectThisPlanButtonforhalfday = By.xpath("//a[@class='half-url']//span[@class='select-popular-text']");		
	// locator to click on hire me button
	By hireMeBtn = By.xpath("//div[@class='container-fluid']//a[@class='hire-me-button']");
	// locator to get the text 
	By available = By.xpath("(//div[text()='4 hrs/d'])[1]");

	// Method to Click on hire button		
	public WishUp_hirePage clickHireBtnOnHomePage() {
		click(by_hireBtnHomePage, ExplicitWaitExpextecConditions.NONE);

		//clickOn(by_hireBtnHomePage);
		//driver.findElement(by_hireBtnHomePage).click();
        logger.info("clicked on hire home page button");
	return this;
	}
	
	// Method to Select VA category
	public WishUp_hirePage selectVACategory() {
		click(by_VACategory, ExplicitWaitExpextecConditions.NONE);

		//clickOn(by_VACategory);
		//driver.findElement(by_VACategory).click();
		logger.info("selected VA Category");
		return this;
	}
	
	// Method to Apply slider for 4hrs
	public WishUp_hirePage applyFourHrsFilter() {
		Actions action = new Actions(driver);
		action.dragAndDropBy(driver.findElement(by_slider), 4, 0).build().perform();
		logger.info("applied filter for four hours");
		return this;
	}
	// Method to Apply slider for 8hrs
	public WishUp_hirePage applyEightHrsFilter() {
		Actions action = new Actions(driver);
		action.dragAndDropBy(driver.findElement(by_slider), 8, 0).build().perform();
		logger.info("applied filter for eight hours");
		return this;
	}
	// Method to Click on view profile button
	public WishUp_hirePage clickOnviewProfileBtn() {
		click(by_viewProfile, ExplicitWaitExpextecConditions.NONE);

		//clickOn(by_viewProfile);
		//driver.findElement(by_viewProfile).click();
		logger.info("clicked on view profile button");
		return this;
	}
	// Method to Enter the skill and search
	public WishUp_hirePage searchSkills(String searchSkill)
	{ 
		enterText(by_searchBar, searchSkill, ExplicitWaitExpextecConditions.PRESENSCE);

		//enterData(by_searchBar, "MS Office CRM");
		//driver.findElement(by_searchBar).sendKeys("MS Office CRM");
		
		Actions act= new Actions(driver);
		act.sendKeys(Keys.ENTER).perform();
		return this;
	}
	
	// Method to Find total VA
	public int verifytotalVACount() 
	{
		int totalva = 0; 
	for(int i=1;i<7;i++) {
		List<WebElement> allprofileList = driver.findElements(by_allprofile);
		totalva=totalva+allprofileList.size();
		System.out.println(totalva);
		JavascriptExecutor js =(JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();",  driver.findElement(by_next));
	
	}
	return totalva;
	
	}
	
}
