package org.wishup.pages;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.ravi.enums.ExplicitWaitExpextecConditions;

public class Wishup_createTask extends BasePage {
	static Logger logger = LogManager.getLogger(Wishup_createTask.class);  
	
//	public Wishup_createTask(WebDriver driver) {
//		this.driver = driver;
//	}
	
	//By by_CreateTaskBtn =By.xpath("//a[@class='ui create_task_button_desktop  circular button']");
	// locator to enter the task name
	By by_TaskName =By.xpath("//div[@class='ui twelve wide column']//input[@name='name']");
	// locator to enter task description
	By by_TaskDiscreption =By.xpath("//trix-editor[@input='task_details']");
	// locator to enter due date
	By by_DueDate =By.xpath("//div[@class='ui computer tablet only grid']//input[@placeholder='Date/Time']");
	// locator to set the frequency
	By by_frequency =By.xpath("//div[@class='ui radio checkbox checked']");
	// locator to team memeber to whom task has to be assigned
	By by_teamMember= By.xpath("//div[@class='ui computer tablet only grid']//div[contains(text(),'SwapG')]");
   // locator to select create task button
	By by_createTaskButton =By.xpath("//div[@class='ui twelve wide column']// button[@type='submit']");
   // locator to select category
	By by_category =By.xpath("//input[@class='search']");
   // locator to select subcategory
	By by_subcategory =By.xpath("//input[@list='sub_categories']");
   // locator to enter the steps
	By by_steps = By.xpath("// trix-editor[@toolbar='trix-toolbar-1']");   
   // locator to enter the links
	By link = By.xpath("//input[@name='links']");
	// locator to select save details button
    By saveDeatilsButton = By.xpath("//div[@class='ui computer tablet only grid']//form[@class='ui form']//button[text()=' Save Details']");

// Method to Enter task name
public Wishup_createTask giveTaskName(String taskName) {
	//driver.findElement(by_TaskName).sendKeys("Wishup QA Assignment ");
	enterText(by_TaskName, taskName, ExplicitWaitExpextecConditions.PRESENSCE);
	//enterData(by_TaskName, "Wishup QA Assignment ");
	logger.info("Task name entered");
	return this;
}
// Enter task description
public Wishup_createTask giveTaskDescreption(String taskDescrip) {
	enterText(by_TaskDiscreption, taskDescrip, ExplicitWaitExpextecConditions.PRESENSCE);

	//driver.findElement(by_TaskDiscreption).sendKeys("Wishup QA Assignment ");
	//enterData(by_TaskDiscreption, "Wishup QA Assignment ");
	logger.info("Task description entered");
	return this;
}
// Method to Enter due date
public Wishup_createTask giveDuedate(String dueDate)  {

	enterText(by_TaskDiscreption, dueDate, ExplicitWaitExpextecConditions.PRESENSCE);
	//driver.findElement(by_DueDate).sendKeys("August 13, 2022");
	//enterData(by_DueDate, "August 13, 2022");
	logger.info("Due date entered entered");
	return this;
}
// Method to Set the frequency
public Wishup_createTask setFrequency() {
	//driver.findElement(by_frequency).click();
	click(by_frequency, ExplicitWaitExpextecConditions.NONE);
	//clickOn(by_frequency);
	logger.info("Frequency is set");
	return this;
}
// Method to Select team member
public Wishup_createTask selectTeamMember() {
	//driver.findElement(by_teamMember).click();	
	click(by_teamMember, ExplicitWaitExpextecConditions.NONE);
	//clickOn(by_teamMember);
	logger.info("team member is selected");
	return this;
}

// Method to Click on create task button
public Wishup_createTask selectCreateTaskBtn() {
	//driver.findElement(by_createTaskButton).click();	
	click(by_createTaskButton, ExplicitWaitExpextecConditions.NONE);
	//clickOn(by_createTaskButton);
	logger.info("clicked on create task button");
	return this;
}

// Method to Enter category
public Wishup_createTask setCategory(String setCategory) {
	//driver.findElement(by_category).sendKeys("Project Management");	
	//enterData(by_category, "Project Management");
	enterText(by_category, setCategory, ExplicitWaitExpextecConditions.PRESENSCE);
	logger.info("Set the category");
	return this;
}
// Method toEnter sub category
public Wishup_createTask sentSubCategory(String setSubCat) {
	//enterData(by_subcategory, "Project Plan");
	enterText(by_subcategory, setSubCat, ExplicitWaitExpextecConditions.PRESENSCE);

	//driver.findElement(by_subcategory).sendKeys("Project Plan");
	logger.info("Select sub category");
	return this;
}
// Method to Enter the steps
public Wishup_createTask setStepsToTask(String setSteps) {
	enterText(by_steps, setSteps, ExplicitWaitExpextecConditions.PRESENSCE);
	//enterData(by_steps, "QA  Assignment");
	//driver.findElement(by_steps).sendKeys("QA  Assignment");
	logger.info("set steps to task");
	return this;
}


// Method to Click on save button
public Wishup_createTask clickSaveBtn() {
	click(saveDeatilsButton, ExplicitWaitExpextecConditions.NONE);
	//clickOn(saveDeatilsButton);
	//driver.findElement(saveDeatilsButton).click();	
	logger.info("Click on saveButton");
	return this;
}
}
