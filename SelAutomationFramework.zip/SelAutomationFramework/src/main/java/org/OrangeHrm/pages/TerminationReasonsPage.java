package org.OrangeHrm.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.ravi.driver.DriverManager;
import org.ravi.enums.ExplicitWaitExpextecConditions;

public class TerminationReasonsPage extends BasePage {

	By by_AddButton = By.xpath("//div[@class='orangehrm-header-container']//button[@type='button']");
	By by_nameFieldAddTermiReason = By.xpath("//div[@class='oxd-form-row']//input[@class='oxd-input oxd-input--active']");
	By by_saveButton = By.xpath("//button[@type='submit']");
	By by_newReason = By.xpath("//div[text()='Poor_Work']");
	By by_editPencilIcon = By.xpath("//div[text()='Poor_Work']//parent::div[1]//following-sibling::div/div/button[2]");
	By by_modifiedReason = By.xpath("//div[text()='non_satisfactory']");
	By by_deleteTermiReason = By.xpath("//div[text()='non_satisfactory']//parent::div[1]//following-sibling::div/div/button[1]");
	By by_yesDeleteButton = By.xpath("(//div[@class='orangehrm-modal-footer']//button[@type='button'])[2]");
	public TerminationReasonsPage clickOnAddButton() {
		 
		click(by_AddButton, ExplicitWaitExpextecConditions.NONE);
         return this;
	}
	
	public TerminationReasonsPage enterNewTerminationReason() {
		enterText(by_nameFieldAddTermiReason, "Poor_Work", ExplicitWaitExpextecConditions.PRESENSCE);
		return this;
	}

	public TerminationReasonsPage clickOnSaveButton() {
		 
		click(by_saveButton, ExplicitWaitExpextecConditions.NONE);
		return this;
	}
	
	public String getnewMethodName() {
		return DriverManager.getDriver().findElement(by_newReason).getText();
	}
	
	public TerminationReasonsPage clickOnPencilIcon()
     
	    {
		click(by_editPencilIcon, ExplicitWaitExpextecConditions.NONE);

		return this;
	    }
	
	public TerminationReasonsPage modifyTerminationReason() throws InterruptedException {
		Thread.sleep(2000);
		WebElement we_editTermiReason = DriverManager.getDriver().findElement(by_nameFieldAddTermiReason);
		Actions act = new Actions(DriverManager.getDriver());
		act.doubleClick(we_editTermiReason).sendKeys("non_satisfactory").build().perform();	
		return this;
	}
	
	public TerminationReasonsPage clickOnSaveButtonAfterModification() {
		 
		click(by_saveButton, ExplicitWaitExpextecConditions.NONE);
		return this;
		
	}
	
	public String getnewMethodNameAfterModification() {
		return DriverManager.getDriver().findElement(by_modifiedReason).getText();
	}
	
	public TerminationReasonsPage deleteTermiReason() throws InterruptedException {
		
		click(by_deleteTermiReason, ExplicitWaitExpextecConditions.NONE);
		Thread.sleep(1000);
	return this;
	
	}

	public TerminationReasonsPage yesdeleteTermiReason() throws InterruptedException {
		
		click(by_yesDeleteButton, ExplicitWaitExpextecConditions.NONE);
		Thread.sleep(1000);
	return this;
	
	}
	
	public boolean verifyTermiReasonDeleted() {
		
		try {
		 DriverManager.getDriver().findElement(by_deleteTermiReason);
		 return true;
		}
		catch (NoSuchElementException e) {
			
			return false;
		}
	}

}
