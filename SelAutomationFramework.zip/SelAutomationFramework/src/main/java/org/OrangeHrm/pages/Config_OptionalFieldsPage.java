package org.OrangeHrm.pages;

import org.openqa.selenium.By;
import org.ravi.enums.ExplicitWaitExpextecConditions;

public class Config_OptionalFieldsPage extends BasePage {
	By by_optionalFieldLink = By.xpath("//a[text()='Optional Fields']");
// following element include Show Nick Name, Smoker and Military Service in Personal Details
	By by_switchForShowDepricatedFields = By.xpath("//span[@class='oxd-switch-input oxd-switch-input--active --label-right']");
//Element from Country Specific Information
	By by_SSNSwitch = By.xpath("(//span[@class='oxd-switch-input oxd-switch-input--active --label-right'])[2]");
    By by_SINSwitch = By.xpath("(//span[@class='oxd-switch-input oxd-switch-input--active --label-right'])[3]");
	By by_saveButton = By.xpath("//button[@type='submit']");
    
	// This method clicks on optional field link
	public Config_OptionalFieldsPage clickOnoptionalFieldLink() {
    	
   	 click(by_optionalFieldLink, ExplicitWaitExpextecConditions.NONE);
   	 return this;
   }
    
	// This method clicks on switches present in front of ShowDepricatedFields
public Config_OptionalFieldsPage clickOnSwitchOfShowDepricatedFields() throws InterruptedException {
	
	 click(by_switchForShowDepricatedFields, ExplicitWaitExpextecConditions.NONE);
	 Thread.sleep(1000);
	 return this;
	 
}

// This method clicks on switches present in front of SSN
public Config_OptionalFieldsPage clickOnSSNSwitch() throws InterruptedException {
	
	 click(by_SSNSwitch, ExplicitWaitExpextecConditions.NONE);
	 Thread.sleep(1000);
	 System.out.println("Clicked on SSNSwitch");
	 return this;
}
 
//This method clicks on switches present in front of SIN
public Config_OptionalFieldsPage clickOnSINSwitch() throws InterruptedException {
	 click(by_SINSwitch, ExplicitWaitExpextecConditions.NONE);
	 Thread.sleep(1000);
	 return this;
}

// This method clicks on save button
public Config_OptionalFieldsPage clickOnSaveButton() throws InterruptedException {
	 click(by_saveButton, ExplicitWaitExpextecConditions.NONE);
	 Thread.sleep(1000);
	 return this;
}

}
