package org.OrangeHrm.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.ravi.driver.DriverManager;
import org.ravi.enums.ExplicitWaitExpextecConditions;

public class AddEmployeePage extends BasePage {

	By by_firstNameTextField = By.xpath("//input[@name='firstName']");
	By by_middleNameTextField = By.xpath("//input[@name='middleName']");
	By by_lastNameTextField = By.xpath("//input[@name='lastName']");
	By by_employeeId = By.xpath("//div[@class='oxd-grid-item oxd-grid-item--gutters']//input[@class='oxd-input oxd-input--active']");
    By by_saveButton = By.xpath("//div[@class='oxd-form-actions']//button[@type='submit']");
    By by_nickName = By.xpath("(//div[@class='oxd-grid-item oxd-grid-item--gutters']//input[@class='oxd-input oxd-input--active'])[1]");
    By by_driverLiecenseNum = By.xpath("(//div[@class='oxd-grid-item oxd-grid-item--gutters']//input[@class='oxd-input oxd-input--active'])[4]");
    By by_licenseExpiryDate = By.xpath("(//div[@class='oxd-grid-item oxd-grid-item--gutters']//input[@class='oxd-input oxd-input--active'])[5]");
    By by_SSNNumber = By.xpath("(//div[@class='oxd-grid-item oxd-grid-item--gutters']//input[@class='oxd-input oxd-input--active'])[6]");
    By by_SINNumber = By.xpath("(//div[@class='oxd-grid-item oxd-grid-item--gutters']//input[@class='oxd-input oxd-input--active'])[7]");
    By by_dateOfBirth = By.xpath("(//div[@class='oxd-grid-item oxd-grid-item--gutters']//input[@class='oxd-input oxd-input--active'])[8]");
    By by_nationalityDropDown = By.xpath("(//div[@class='oxd-select-text-input'])[1]"); // loop i=3;
    By by_maritialStatusDropDown = By.xpath("(//div[@class='oxd-select-text-input'])[2]");// i=1;
    By by_savePersonalDetailButton = By.xpath("(//button[@type=\"submit\"])[1]");
    By by_saveCustomFieldButton = By.xpath("(//button[@type=\"submit\"])[2]");
    By by_bloodTypeDropDown = By.xpath("(//div[@class='oxd-select-text-input'])[3]");// i=3 B+
    By by_maleRadioButton = By.xpath("(//div[@class='oxd-radio-wrapper'])[1]");
    
	

	public AddEmployeePage enterFirstName() {
		enterText(by_firstNameTextField, "Morgan", ExplicitWaitExpextecConditions.PRESENSCE);	
		return this;
	}

	public AddEmployeePage enterMiddleName() {
		enterText(by_middleNameTextField, "Win", ExplicitWaitExpextecConditions.PRESENSCE);	
		return this;
	}

	public AddEmployeePage enterLastName() {
		enterText(by_lastNameTextField, "Diesel", ExplicitWaitExpextecConditions.PRESENSCE);	
		return this;
	}
	
	 public AddEmployeePage enterEmployeeId() {	
		 enterText(by_employeeId, "0023", ExplicitWaitExpextecConditions.PRESENSCE);	
			return this;
	    }
	 
	 public AddEmployeePage clickOnSaveButton() {
	    	click(by_saveButton, ExplicitWaitExpextecConditions.NONE);
	    	return this;
	    	}
	 
	 public AddEmployeePage enterEmployeeNickName() {	
		 enterText(by_nickName, "John", ExplicitWaitExpextecConditions.PRESENSCE);	
			return this;
	    }
	 
	 public AddEmployeePage enterDrivingLicenseNum() {	
		 enterText(by_driverLiecenseNum, "313918", ExplicitWaitExpextecConditions.PRESENSCE);	
			return this;
	    }
	 public AddEmployeePage enterLicenseExpiryDate() {	
		 enterText(by_licenseExpiryDate, "2022-12-03", ExplicitWaitExpextecConditions.PRESENSCE);	
			return this;
	    }
	 public AddEmployeePage enterSSNNum() {	
		 enterText(by_SSNNumber, "123456", ExplicitWaitExpextecConditions.PRESENSCE);	
			return this;
	    }
	 public AddEmployeePage enterSINNum() {	
		 enterText(by_SINNumber, "123654", ExplicitWaitExpextecConditions.PRESENSCE);	
			return this;
	    }
	 public AddEmployeePage selectNationality() throws InterruptedException {
			WebElement we_nationName = DriverManager.getDriver().findElement(by_nationalityDropDown);
			we_nationName.click();
			for(int i=0; i<=3; i++) {
				we_nationName.sendKeys(Keys.ARROW_DOWN);
			}
			Thread.sleep(1000);
			we_nationName.click();
			return this;
		}
	 
	 public AddEmployeePage selectMaritialStatus() throws InterruptedException {
			WebElement we_maritialStatus = DriverManager.getDriver().findElement(by_maritialStatusDropDown);
			we_maritialStatus.click();
			for(int i=0; i<=1; i++) {
				we_maritialStatus.sendKeys(Keys.ARROW_DOWN);
			}
			Thread.sleep(1000);
			we_maritialStatus.click();
			return this;
		}
	 public AddEmployeePage enterDateOfBirth() {	
		 enterText(by_dateOfBirth, "1993-10-05", ExplicitWaitExpextecConditions.PRESENSCE);	
			return this;
	    }
	 public AddEmployeePage clickOnMaleRadioButton() {	
		 click(by_maleRadioButton, ExplicitWaitExpextecConditions.NONE);
			return this;
	    }
	 
	 public AddEmployeePage clickOnSavePersonalDetails() {	
		 click(by_savePersonalDetailButton, ExplicitWaitExpextecConditions.NONE);
			return this;
	    }
	 
	 public AddEmployeePage selectBloodGroup() throws InterruptedException {
			WebElement we_bloodGroup = DriverManager.getDriver().findElement(by_bloodTypeDropDown);
			we_bloodGroup.click();
			for(int i=0; i<=3; i++) {
				we_bloodGroup.sendKeys(Keys.ARROW_DOWN);
			}
			Thread.sleep(1000);
			we_bloodGroup.click();
			return this;
		}
	 public AddEmployeePage clickOnSaveCustomField() {	
		 click(by_saveCustomFieldButton, ExplicitWaitExpextecConditions.NONE);
			return this;
	    }
	 
}
