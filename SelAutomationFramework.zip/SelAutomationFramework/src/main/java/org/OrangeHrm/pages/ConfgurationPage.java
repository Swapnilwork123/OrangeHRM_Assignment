package org.OrangeHrm.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.ravi.driver.DriverManager;
import org.ravi.enums.ExplicitWaitExpextecConditions;

public class ConfgurationPage extends  BasePage{

	By by_confiurationLink = By.xpath("//span[text()='Configuration ']");
	By by_termnationRasonsLink = By.xpath("//a[text()='Termination Reasons']");
	By by_reportingMethod = By.xpath("//a[text()='Reporting Methods']");
	By by_addButton = By.xpath("//div[@class='orangehrm-header-container']//button[@type='button']");
	By by_reortingMethodNameBox = By.xpath("//div[@class='oxd-form-row']//input[@class='oxd-input oxd-input--active']");
	By by_saveButton = By.xpath("//button[@type='submit']");
	//following element gives new method
	By by_getNewMethodName = By.xpath("(//div[@class='oxd-table-cell oxd-padding-cell'])[8]");
	By by_modifyButton = By.xpath("(//button[@type='button'])[8]");
	By by_editNewMethodName = By.xpath("//div[@class='oxd-form-row']//input[@class='oxd-input oxd-input--active']");
	By by_saveButtonEditedMethodName = By.xpath("//button[@type='submit']");
	By by_getModifiedMethodName = By.xpath("(//div[@role='cell'])[8]");
	By by_deleteButton = By.xpath("(//button[@type=\"button\"])[7]");
	By by_yesDeleteButton = By.xpath("//button[@class='oxd-button oxd-button--medium oxd-button--label-danger orangehrm-button-margin']");
	
	// Following method used to perform click operation on configuration link
	public ConfgurationPage clickOnConfiguartion() {
      click(by_confiurationLink, ExplicitWaitExpextecConditions.NONE);
      return this;
	}
	
	// Following method used to perform click operation on reporting method
	public ConfgurationPage clikOnReportingMethod() {
		click(by_reportingMethod, ExplicitWaitExpextecConditions.NONE);
		return this;
	}
	
	// Following method used to perform click operation on add button
	public ConfgurationPage clickOnAddButton() {
		click(by_addButton, ExplicitWaitExpextecConditions.NONE);
		return this;
	}
	
	// Following method used to enter method name in method name field
	public ConfgurationPage enterNewMethodName() {
		enterText(by_reortingMethodNameBox, "Method_One", ExplicitWaitExpextecConditions.PRESENSCE);
		return this;
	}
	
	// Following method used to perform click operation on save button
	public ConfgurationPage clickOnSaveButton() throws InterruptedException {
		Thread.sleep(5000);
		click(by_saveButton, ExplicitWaitExpextecConditions.NONE);
		return this;
	}
	
	// This method give method name 
	public String getMethodName() {
		String str_methodName = DriverManager.getDriver().findElement(by_getNewMethodName).getText();
		System.out.println(str_methodName);
		return str_methodName;
	}
	
	// Following method used to perform click operation on pencil icon
	public ConfgurationPage clickOnPencilIcon() {
		click(by_modifyButton, ExplicitWaitExpextecConditions.NONE);
		return this;
	}
	
	// This method modifies the method name 
	public ConfgurationPage modifyMethodName() throws InterruptedException {
		Thread.sleep(2000);
		WebElement we_editMethodN = DriverManager.getDriver().findElement(by_editNewMethodName);
		Actions act = new Actions(DriverManager.getDriver());
		act.doubleClick(we_editMethodN).sendKeys("Method_Modified").build().perform();	
		return this;
	}

	// This method save the modified changes in method name
	public ConfgurationPage clickOnSaveModified() throws InterruptedException {
		Thread.sleep(5000);
		click(by_saveButton, ExplicitWaitExpextecConditions.NONE);	
		return this;	
	}
	
	// This method gives the modified method name
	public String getModifiedMethodName() {
		String str_modifiedMethodName = DriverManager.getDriver().findElement(by_getModifiedMethodName).getText();
		System.out.println(str_modifiedMethodName);
		return str_modifiedMethodName;
	}
	
	// Following method clicks on delete button
	public ConfgurationPage clickOnDeleteButton() throws InterruptedException {

	      click(by_deleteButton, ExplicitWaitExpextecConditions.NONE);
	      
	      Thread.sleep(2000);
	      return this;
		}
	
	// Following method click on Yes delete button
	public ConfgurationPage clickOnYesDeleteButton() throws InterruptedException {
	      click(by_yesDeleteButton, ExplicitWaitExpextecConditions.NONE);
	      Thread.sleep(2000);
	      return this;
		}
	
	// This method checks weather element present or not on page 
	public boolean isElementPresent() {
		try {
		DriverManager.getDriver().findElement(by_getModifiedMethodName).isDisplayed();
		return true;
		}
		catch(NoSuchElementException e){
			return false;
		}
	}
	
	// This method clicks on termination link
	public ConfgurationPage clickOnTerminationReasonLink() throws InterruptedException {
	      click(by_termnationRasonsLink, ExplicitWaitExpextecConditions.NONE);
	      Thread.sleep(2000);
	      return this;
		}
}
                                                                                                                                                                                                                                                                                                                                     