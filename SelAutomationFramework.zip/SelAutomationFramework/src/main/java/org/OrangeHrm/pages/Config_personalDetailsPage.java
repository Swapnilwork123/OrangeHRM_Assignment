package org.OrangeHrm.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.ravi.driver.DriverManager;

public class Config_personalDetailsPage extends BasePage {

	By by_nicknameTextField = By.xpath("(//div[@class='oxd-input-group oxd-input-field-bottom-space']"
			+ "//input[@class='oxd-input oxd-input--active'])[1]");

	By by_milteryServicesTextField = By.xpath("(//div[@class='oxd-input-group oxd-input-field-bottom-space']"
			+ "//input[@class='oxd-input oxd-input--active'])[9]");

	By by_SSNnumberTextField = By.xpath("(//div[@class='oxd-input-group oxd-input-field-bottom-space']"
			+ "//input[@class='oxd-input oxd-input--active'])[6]");

	By by_SINnumberTextField = By.xpath("(//div[@class='oxd-input-group oxd-input-field-bottom-space']"
			+ "//input[@class='oxd-input oxd-input--active'])[7]");

	// This method check Nickname text field is present or not
	public boolean isNicknameElementPresent() {
		try {
			DriverManager.getDriver().findElement(by_nicknameTextField).isDisplayed();
			return true;
		} catch (NoSuchElementException e) {

			return false;
		}
	}
	// This method check Miletory service text field is present or not
	public boolean ismilteryServicesElementPresent() {
		try {
			DriverManager.getDriver().findElement(by_milteryServicesTextField).isDisplayed();
			return true;
		} catch (NoSuchElementException e) {

			return false;
		}
	}

	//This method check SSN text field is present or not
	public boolean isSSNnumberElementPresent() {
		try {
			DriverManager.getDriver().findElement(by_SSNnumberTextField).isDisplayed();
			return true;
		} catch (NoSuchElementException e) {

			return false;
		}
	}
	//This method check SIN text field is present or not
	public boolean isSINnumberElementPresent() {
		try {
			DriverManager.getDriver().findElement(by_SINnumberTextField).isDisplayed();
			return true;
		} catch (NoSuchElementException e) {

			return false;
		}
	}
}