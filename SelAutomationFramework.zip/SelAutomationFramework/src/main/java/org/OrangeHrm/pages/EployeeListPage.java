package org.OrangeHrm.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.ravi.driver.DriverManager;
import org.ravi.enums.ExplicitWaitExpextecConditions;

public class EployeeListPage extends BasePage{

	By by_employeeListLink = By.xpath("//a[text()='Employee List']");
	By by_Employee = By.xpath("(//div[@class='oxd-table-card'])[7]");
    By by_employeeNameField = By.xpath("(//input[@placeholder='Type for hints...'])[1]");
    By by_employeeIdField = By.xpath("//div[@class='oxd-grid-item oxd-grid-item--gutters']//input[@class='oxd-input oxd-input--active']");
	By by_employeeStatusDropDown = By.xpath("(//div[@class=\"oxd-select-text-input\"])[1]");
	By by_employeeStatusSelect = By.linkText("Full-Time Contract");
	//By by_employeeStatusSelect= By.partialLinkText("Full-Time C");
	By by_searchButton = By.xpath("//button[@type='submit']");
    By by_emloyeeSearchResult = By.xpath("(//div[@class=\"oxd-table-cell oxd-padding-cell\"])[3]");
    By by_supervisorNameTextField = By.xpath("(//input[@placeholder='Type for hints...'])[2]");
    By by_jobTitleDropDown = By.xpath("(//div[@class='oxd-select-text-input'])[3]");
    By by_subUnitDropDown = By.xpath("(//div[@class='oxd-select-text-input'])[4]");
    
    By by_addButton = By.xpath("//div[@class='orangehrm-header-container']//button[@type='button']");
    
    
    
    public EployeeListPage clickOnemployeeListLink() {
		 click(by_employeeListLink, ExplicitWaitExpextecConditions.NONE);
		 return this;
	}
	
	public EployeeListPage clickOnEmployeeFromRecord() {
		 click(by_Employee, ExplicitWaitExpextecConditions.NONE);
		 return this;
	}
	
	public EployeeListPage enterEmployeeName() {
		
		enterText(by_employeeNameField, "Jordan  Mathews", ExplicitWaitExpextecConditions.PRESENSCE);	
		return this;
	}
	
	public EployeeListPage pressDownArrow() throws InterruptedException {
		
		Actions act = new Actions(DriverManager.getDriver());
		
		act.keyDown(Keys.ARROW_DOWN).build().perform();
		act.keyUp(Keys.ARROW_DOWN);
		Thread.sleep(1000);
		return this;
	}
	
	public EployeeListPage enterEmployeeId() {
		
		enterText(by_employeeIdField, "0054", ExplicitWaitExpextecConditions.PRESENSCE);	
		return this;
		
	}
	
	public EployeeListPage clickOnEmployeeStatusDropdown() throws InterruptedException {
		
		WebElement we_employeeStatusDropdown = DriverManager.getDriver().findElement(by_employeeStatusDropDown);
		we_employeeStatusDropdown.click();
		
		for(int i=0; i<2; i++)
		{
			
		 we_employeeStatusDropdown.sendKeys(Keys.ARROW_DOWN);
		
		}
		we_employeeStatusDropdown.sendKeys(Keys.ENTER);
		
	    
		//Select select = new Select(we_employeeStatusDropdown);
	//	select.selectByVisibleText("Full-Time Contract");
		// click(by_employeeStatusDropDown, ExplicitWaitExpextecConditions.NONE);
		 Thread.sleep(1000);
		// click(by_employeeStatusSelect, ExplicitWaitExpextecConditions.NONE);

		return this;
	}
	
	
	public EployeeListPage clickOnSearchButton() throws InterruptedException {
		 click(by_searchButton, ExplicitWaitExpextecConditions.NONE);
		 System.out.println("Clicked on search button");
		 Thread.sleep(1000);
		 return this; 
	}
	
	public String verifySearchResult() {
		return DriverManager.getDriver().findElement(by_emloyeeSearchResult).getText();
		
	}

	public EployeeListPage enterSupervisorName() {
		
		enterText(by_supervisorNameTextField, "Cassidy Hope", ExplicitWaitExpextecConditions.PRESENSCE);	
		return this;
	}
	
	public EployeeListPage selectJobTitle() throws InterruptedException {
		WebElement we_jobTitle = DriverManager.getDriver().findElement(by_jobTitleDropDown);
		we_jobTitle.click();
		for(int i=0; i<=6; i++) {
			we_jobTitle.sendKeys(Keys.ARROW_DOWN);
		}
		Thread.sleep(1000);
		we_jobTitle.click();
		
		return this;
	}
	
	public EployeeListPage selectSubUnit() throws InterruptedException {

		WebElement we_subUnit = DriverManager.getDriver().findElement(by_subUnitDropDown);
		we_subUnit.click();

		for (int i = 0; i <=5; i++) {
			
			we_subUnit.sendKeys(Keys.ARROW_DOWN);
		}
		Thread.sleep(10000);
		we_subUnit.click();
		

		return this;
	}
	
	
	 public EployeeListPage clickOnAddButton() {
		 click(by_addButton, ExplicitWaitExpextecConditions.NONE);
		 return this;
	}
}
