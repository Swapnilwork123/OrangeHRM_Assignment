package org.OrangeHrm.pages;

import org.openqa.selenium.By;
import org.ravi.driver.DriverManager;
import org.ravi.enums.ExplicitWaitExpextecConditions;

public class LoginPage_OrangeHm extends BasePage{

	By by_UsernameField = By.xpath("//input[@placeholder='Username']");
	By by_PasswordField = By.xpath("//input[@type='password']");
	By by_LoginBtn = By.xpath("//button[@type='submit']");
	
	public LoginPage_OrangeHm enterUserName(String userName) throws InterruptedException {
		Thread.sleep(1000);
		enterText(by_UsernameField, userName, ExplicitWaitExpextecConditions.PRESENSCE);
		System.out.println("username entered");
		return this;
	}
	public LoginPage_OrangeHm enterPassword(String password) throws InterruptedException {
		Thread.sleep(1000);
		enterText(by_PasswordField, password, ExplicitWaitExpextecConditions.PRESENSCE);
		System.out.println("pasward entered");
		return this;
	}
    
	public LoginPage_OrangeHm clickOnLoginBtn() throws InterruptedException {
		Thread.sleep(1000);
		click(by_LoginBtn, ExplicitWaitExpextecConditions.NONE);
		return this;
	}
	
	public String getUrl()
{
	String Str_urlAfterLogin = DriverManager.getDriver().getCurrentUrl();
	System.out.println(Str_urlAfterLogin);
	System.out.println(DriverManager.getDriver().getTitle());
	return Str_urlAfterLogin;
}
}
